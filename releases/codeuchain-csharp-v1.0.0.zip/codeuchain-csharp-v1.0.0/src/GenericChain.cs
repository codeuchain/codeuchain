// This file is now empty after reorganization
// All classes and interfaces have been moved to their appropriate files:
// - Context<T> -> Context.cs
// - IContextLink<TInput, TOutput> -> ILink.cs
// - IMiddleware<T> -> IMiddleware.cs
// - Chain<TInput, TOutput> -> Chain.cs