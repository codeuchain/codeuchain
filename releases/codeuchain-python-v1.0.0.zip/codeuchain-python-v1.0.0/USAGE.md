CodeUChain - Release Package

This release contains only the language-specific package source and examples for quick download.

See the main repository README for language-specific build instructions.
