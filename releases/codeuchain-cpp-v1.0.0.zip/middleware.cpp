#include "codeuchain/middleware.hpp"

// This file contains the interface definition only
// Concrete implementations should inherit from IMiddleware